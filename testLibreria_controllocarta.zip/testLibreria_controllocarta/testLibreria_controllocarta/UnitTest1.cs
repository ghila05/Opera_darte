using controllocarta;
namespace testLibreria_controllocarta
{
    public class UnitTest1
    {

        CartaDiCredito carta = new CartaDiCredito(4810642942732885); //carta valida  

        CartaDiCredito carta1 = new CartaDiCredito(4716435917330099); // carta valida

        CartaDiCredito carta2 = new CartaDiCredito(47164359173300990);  //pi� cifre non valida

        CartaDiCredito carta3 = new CartaDiCredito(4716435987330099);  //cifre con risultato non divisibile


        [Fact]

        public void Test1()
        {
            Assert.True(carta.IsValid() == true);  // SOSPETTO BUG 
        }


        [Fact]
        public void Test2()
        {
            Assert.True(carta1.IsValid() == true);
        }

        [Fact]
        public void Test3()
        {
            Assert.True(carta2.IsValid() == false);
        }

        [Fact]
        public void Test4()
        {
            Assert.True(carta3.IsValid() == false);
        }

        [Fact]

        public void Test5()
        {
            Assert.True(carta.Confronta(0000000000000000) == 1);
        }

        [Fact]
        public void Test6()
        {
            Assert.True(carta.Confronta(4810642942732885) == 16); 
        }

        [Fact]
        public void Test7()
        {
            Assert.True(carta.Confronta(4) == 1);  // GIUSTA LA POSIZIONE MA CI DOVREBBE ESSERE UN'ECCEZIONE DATO VCHE IL NUMERO NON � DI 16 CIFRE
        }

        [Fact]

        public void Test8()
        {
            long A, b;
            A = carta.GeneraNumeroValido();
            b = carta1.GeneraNumeroValido();
            Assert.True(A != b == true);
        }

        [Fact]
        public void Test9()
        {
            string a = carta.ToString();
            Assert.True(a != null);
        }


    }
}